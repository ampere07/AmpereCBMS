<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Direct Routes
|--------------------------------------------------------------------------
|
| These routes have minimal middleware
|
*/

// Direct API routes go here

